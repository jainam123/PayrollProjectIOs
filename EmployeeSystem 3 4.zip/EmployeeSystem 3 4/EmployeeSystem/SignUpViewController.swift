//
//  SignUpViewController.swift
//  EmployeeSystem
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var txtnm: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
  
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtconfirmPass: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnsignUp(_ sender: Any) {
        if txtPassword.text == txtconfirmPass.text
        {
            let alertmsg  = UIAlertController(title: "Message", message: "Register Successfully", preferredStyle: UIAlertControllerStyle.actionSheet)
            let actionOk = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
            alertmsg.addAction(actionOk)
            self.present(alertmsg, animated: true, completion: nil)
            /* let storyBoard = UIStoryboard(name: "Main", bundle: nil)
             let thirdVC = storyBoard.instantiateViewController(withIdentifier: "login") as! LoginViewController
             self.present(thirdVC, animated: true, completion: nil)*/
        }
        else{
            let alertmsg1  = UIAlertController(title: "Message", message: "Password not match", preferredStyle: UIAlertControllerStyle.actionSheet)
            let actionOk = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
            alertmsg1.addAction(actionOk)
            self.present(alertmsg1, animated: true, completion: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
