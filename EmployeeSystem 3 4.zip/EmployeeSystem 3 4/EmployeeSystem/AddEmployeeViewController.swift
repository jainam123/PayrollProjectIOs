//
//  AddEmployeeViewController.swift
//  EmployeeSystem
//
//  Created by MacStudent on 2018-08-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class AddEmployeeViewController: UIViewController {

    @IBOutlet weak var txtEmployeeNm: UITextField!
   
    @IBOutlet weak var txtVehicleModel: UITextField!
    
    @IBOutlet weak var txtVehiclePlate: UITextField!

    @IBOutlet weak var commPerc: UITextField!
    @IBOutlet weak var fixedamt: UITextField!
    @IBOutlet weak var workdhour: UITextField!
    @IBOutlet weak var hourRate: UITextField!  
    @IBOutlet weak var schoolName: UITextField!
    @IBOutlet weak var empsalry: UITextField!
    @IBOutlet weak var empBonus: UITextField!
    @IBOutlet weak var segmntVehicle: UISegmentedControl!
    @IBOutlet weak var segmntEmp: UISegmentedControl!

    @IBOutlet weak var segmntPart: UISegmentedControl!
    @IBOutlet weak var switchOutlt: UISwitch!
  
    @IBOutlet weak var segmntPT: UISegmentedControl!
    @IBAction func switchV(_ sender: Any) {
       
        if(switchOutlt.isOn == true)
        {
             txtVehiclePlate.isHidden = false
            txtVehicleModel.isHidden = false
            segmntVehicle.isHidden = false
        }
        else
        {
            txtVehiclePlate.isHidden = true
            txtVehicleModel.isHidden = true
            segmntVehicle.isHidden = true
        }
        }
       
    @IBAction func segmnt2(_ sender: Any) {
       workdhour.isHidden = false
        hourRate.isHidden = false
        if(segmntEmp.selectedSegmentIndex == 0)
        {
            schoolName.isHidden = true
            empBonus.isHidden = true
            empsalry.isHidden = true
            workdhour.isHidden = false
            segmntPart.isHidden = false
            hourRate.isHidden = false
        }
        else if(segmntEmp.selectedSegmentIndex == 1)
        {
            empBonus.isHidden = true
            empsalry.isHidden = true
            segmntPart.isHidden = true
            workdhour.isHidden = true
            empsalry.isHidden = true
             schoolName.isHidden = false
            hourRate.isHidden = true
            segmntPart.isHidden = true
        }
        else if(segmntEmp.selectedSegmentIndex == 2)
        {
            segmntPart.isHidden = true
            workdhour.isHidden = true
            empsalry.isHidden = true
            schoolName.isHidden = true
            hourRate.isHidden = true
            empBonus.isHidden = false
            empsalry.isHidden = false
            segmntPart.isHidden = true
        }
    }
    @IBAction func segmnt3PT(_ sender: Any) {
        if(segmntPT.selectedSegmentIndex == 0)
        {
            commPerc.isHidden = false
            fixedamt.isHidden = true
        }
        else{
            commPerc.isHidden = true
            fixedamt.isHidden = false
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
